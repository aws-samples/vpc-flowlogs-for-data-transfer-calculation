from __future__ import print_function
import boto3 
import json
import botocore.exceptions as exceptions
import urllib3
SUCCESS = "SUCCESS"
FAILED = "FAILED"
http = urllib3.PoolManager()
ec2 = boto3.client('ec2')

def send(event, context, responseStatus, responseData, reason=None, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {
        'Status' : responseStatus,
        'Reason' : reason or "See the details in CloudWatch Log Stream: {}".format(context.log_stream_name),
        'PhysicalResourceId' : physicalResourceId or context.log_stream_name,
        'StackId' : event['StackId'],
        'RequestId' : event['RequestId'],
        'LogicalResourceId' : event['LogicalResourceId'],
        'NoEcho' : noEcho,
        'Data' : responseData
    }

    json_responseBody = json.dumps(responseBody)

    print("Response body:")
    print(json_responseBody)

    headers = {
        'content-type' : '',
        'content-length' : str(len(json_responseBody))
    }

    try:
        response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)
        print("Status code:", response.status)


    except Exception as e:
        print("send(..) failed executing http.request(..):", e)
        
        
def createVPCFlowLogs(vpcIds,logGroupArn,vpcFlogLogPublishRole):
    vpc_flow_log = ec2.create_flow_logs(
        DeliverLogsPermissionArn=vpcFlogLogPublishRole,
        ResourceIds=vpcIds,
        ResourceType='VPC',
        TrafficType='ACCEPT',
        LogDestinationType='cloud-watch-logs',
        LogDestination=logGroupArn
    )    
    
def deleteVPCFlowLogs(vpcIds):
    flow_log_id_list = []
    
    flow_log_ids = ec2.describe_flow_logs(
        Filter=[{'Name': 'resource-id', 'Values': vpcIds}]
    )

    for item in flow_log_ids['FlowLogs']:
        flow_log_id_list.append(item['FlowLogId'])
      
    if len(flow_log_id_list) == 0: # if no flowlogs exist
        pass
        
    else:
        deleted_vpc_flow_log = ec2.delete_flow_logs(
            FlowLogIds = flow_log_id_list    
        )
        

        
def lambda_handler(event, context):
    responseData = {}
    physicalResourceId = "createVPCFlowLogs"
    print ('REQUEST BODY:n' + str(event))
    vpcIds = event['ResourceProperties']['VpcIds']
    logGroupArn = event['ResourceProperties']['LogGroupArn']
    vpcFlogLogPublishRole = event['ResourceProperties']['VpcFlogLogPublishRole']
    requestType = event['RequestType']
    if requestType == "Create":
        try: 
            createVPCFlowLogs(vpcIds,logGroupArn,vpcFlogLogPublishRole)
            responseStatus = SUCCESS
        except Exception as e:
            print (e)
            responseStatus = FAILED
    elif requestType == "Update":
        oldVpcIds = event['OldResourceProperties']['VpcIds']
        try: 
            deleteVPCFlowLogs(oldVpcIds)
            createVPCFlowLogs(vpcIds,logGroupArn,vpcFlogLogPublishRole)
            responseStatus = SUCCESS

        except Exception as e:
            print (e)
            responseStatus = FAILED
    elif requestType == "Delete":
        try: 
            deleteVPCFlowLogs(vpcIds)
            responseStatus = SUCCESS
            
        except Exception as e:
            print (e)
            responseStatus = FAILED
    
    send(event, context, responseStatus, responseData)
